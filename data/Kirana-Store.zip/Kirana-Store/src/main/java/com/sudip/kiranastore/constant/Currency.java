package com.sudip.kiranastore.constant;

public enum Currency {
    INR,
    EUR, USD
}
