package com.sudip.kiranastore.constant;

public enum TransactionType {
    CREDIT,
    UNKNOWN, DEBIT
}
